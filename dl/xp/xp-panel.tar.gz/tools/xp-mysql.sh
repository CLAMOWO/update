#!/bin/bash
# 判断mysql路径不存在，则提示安装
if [ ! -f "/xp/server/mysql/bin/mysql" ]; then
    echo "mysql未安装，请先从面板的软件中心安装mysql"
    exit 1
fi
LD_LIBRARY_PATH="/xp/server/mysql/bin/depends" /xp/server/mysql/bin/mysql $@