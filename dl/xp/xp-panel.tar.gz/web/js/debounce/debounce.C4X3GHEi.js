let e;const t=(t,o)=>(...a)=>{e&&clearTimeout(e),e=setTimeout((()=>{t.apply(void 0,a)}),o)};export{t as d};
