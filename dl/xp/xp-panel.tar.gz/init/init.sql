-- init panel's user data
INSERT INTO users ("id", "created_time", "updated_time", "account", "password") VALUES (1, '{time}', '{time}', '{account}', '{pwdMd5}');

-- init panel's default config
-- type: 1-bool, 2-int, 3-str

INSERT INTO panel_cfgs (section, key, type, value) VALUES ('base', 'PanelSwitch', 1, 'true'); -- 面板开关
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('base', 'SSL', 1, 'false'); -- SSL开关 
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('base', 'SSLType', 2, '0'); -- SSL证书类型 
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('base', 'SSLKey', 3, ''); -- SSL证书key
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('base', 'SSLPwd', 3, ''); -- SSL证书密码
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('base', 'SSLPem', 3, ''); -- SSL证书pem
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('base', 'API', 1, 'false'); -- API开关 
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('base', 'APIKey', 3, ''); -- API接口的Key
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('base', 'APIWhiteList', 3, ''); -- API接口的白名单
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('base', 'IPV6', 1, 'false'); -- IPV6 
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('base', 'XPAccount', 3, ''); -- XP账号
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('base', 'UserPlan', 1, 'false'); -- 用户体验计划

INSERT INTO panel_cfgs (section, key, type, value) VALUES ('xpPanelToken', 'Token', 3, ''); -- xp账号绑定信息
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('xpPanelToken', 'RefreshToken', 3, ''); -- xp账号绑定信息

INSERT INTO panel_cfgs (section, key, type, value) VALUES ('panel', 'Alias', 3, '小皮面板'); -- 面板别名
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('panel', 'Domain', 3, ''); -- 面板域名
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('panel', 'Port', 2, '{port}'); -- 面板端口
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('panel', 'Account', 3, '{account}'); -- 面板账号
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('panel', 'Entry', 3, '{safeEntry}'); -- 安全入口
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('panel', 'SiteDir', 3, '/xp/www'); -- 建站目录
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('panel', 'BackupDir', 3, '/xp/backup'); -- 备份目录
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('panel', 'XPVersion', 3, '{xpVersion}'); -- XP版本
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('panel', 'DemoMode', 1, 'false'); -- 演示模式
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('panel', 'DeleteSoftPkg', 1, 'true'); -- 是否自动删除下载的软件包

INSERT INTO panel_cfgs (section, key, type, value) VALUES ('security', 'AuthIP', 3, ''); -- 授权IP
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('security', 'PwdExpireDay', 2, '0'); -- 面板密码有效时间

INSERT INTO panel_cfgs (section, key, type, value) VALUES ('push', 'WxPush', 1, 'false'); -- 微信公众号推送开关
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('push', 'Email', 3, ''); -- 接收邮件推送的地址
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('push', 'DingRobot', 3, ''); -- 钉钉机器人
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('push', 'WxOrgRobot', 3, ''); -- 企业微信机器人
INSERT INTO panel_cfgs (section, key, type, value) VALUES ('push', 'FeiShuRobot', 3, ''); -- 飞书机器人
 
-- init default terminal data
INSERT INTO "main"."terminals" ("id", "created_time", "updated_time", "ip", "port", "ssh_account", "remark", "verity_way", "password", "key", "key_password", "ssh_tunnel_machine_id") VALUES (1, '{time}', '{time}', '127.0.0.1', '22', 'root', '本机终端', 0, '', '', '', 0);

-- init recyle default data
INSERT INTO recycle_bin_configs (file, sql,created_time,updated_time) VALUES (1, 1,'{time}','{time}');

-- init firewall default data
INSERT INTO firewall_configs (status,created_time,updated_time) VALUES (1,'{time}','{time}');
INSERT INTO firewall_ports (remark,port,created_time,updated_time) VALUES ('小皮面板端口','{port}','{time}','{time}');

-- init surveillance default data
INSERT INTO surveillance_configs (status,retention_period,created_time,updated_time) VALUES (1,30,'{time}','{time}');