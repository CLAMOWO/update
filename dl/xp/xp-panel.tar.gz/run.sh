#!/bin/bash
if [ ! -d "/xp/panel/tmp" ];then
    mkdir -p /xp/panel/tmp
fi
if [ ! -d "/xp/tasks/tmp" ];then
    mkdir -p /xp/tasks/tmp
fi
if [ ! -f "/xp/panel/app.log" ];then
    touch /xp/panel/app.log
fi
if [ ! -f "/xp/tasks/xp-tasks.log" ];then
    touch /xp/tasks/xp-tasks.log
fi

if ps aux | grep -v grep | grep /xp/panel/app > /dev/null; then
    pkill -f /xp/panel/app
fi
if ps aux | grep -v grep | grep /xp/tasks/xp-task > /dev/null; then
    pkill -f /xp/tasks/xp-task
fi

setsid /xp/panel/app >> /xp/panel/app.log &
setsid /xp/tasks/xp-tasks-start >> /xp/tasks/xp-tasks.log &

echo "xp面板已启动"