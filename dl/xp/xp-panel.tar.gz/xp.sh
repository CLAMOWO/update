#!/bin/bash
echo -e "================================小皮面板命令行=================================="
echo -e "(1)重启面板服务                    (2)停止面板服务                             |"
echo -e "(3)启动面板服务                    (4)修改面板密码                             |"
echo -e "(5)修改面板用户名                  (6)修改面板端口                             |" 
echo -e "(7)打开面板                        (8)查看面板默认信息                         |"
echo -e "(9)修改安全入口                    (10)修复面板数据库                          |"
echo -e "(11)卸载面板                       (0)取消                                     |"
echo -e "================================================================================"
echo "请输入命令编号："
read number
Panel_restart() {
    sudo service xpd restart  
}
Panel_stop() {
    sudo service xpd stop
}
Panel_start(){
    sudo service xpd start
}
Panel_editpwd(){
    echo "请输入新密码："
    read password
    # 判断密码的格式是否正确
    if [ ! -z "${password}" ]; then
        pwd_md5=$(echo -n $password | md5sum | cut -d ' ' -f 1)
        sqlite3 -batch /xp/db/app.db "UPDATE  users SET password='${pwd_md5}' WHERE id =1;"
        echo "| 新密码为：$password"
    else
        echo "密码格式不正确"
    fi
}
Panel_edituser(){
    echo "请输入新用户名："
    read username
    # 判断用户名不为空
    if [ ! -z "${username}" ];then
        sqlite3 -batch /xp/db/app.db "UPDATE  panel_cfgs SET value='$username' WHERE section = 'panel' and key ='Account';UPDATE  users SET account='${username}' WHERE id =1"
        echo "| 新用户名为：$username"
    else
        echo "用户名格式不正确"
    fi
}
Panel_safeport(){
    echo "请输入新的安全入口(不支持/ .符号)："
    read port
    # 判断安全端口长度大于0且不含/和.
    if [[ $port =~ ^[^/\.]{1,}$ ]]; then
        sqlite3 -batch /xp/db/app.db "UPDATE  panel_cfgs SET value='$port' WHERE section = 'panel' and key ='Entry';"
        Panel_restart
        echo "| 新的安全入口为：$port"
    else
        echo "安全入口格式不正确"
    fi 
}
Panel_editport(){
    echo "请输入新端口："
    read port
    # 判断端口是否为数字
    if [[ $port =~ ^[0-9]+$ ]]; then
        oldPort=$(sqlite3 -batch /xp/db/app.db "SELECT value FROM panel_cfgs where section = 'panel' and key = 'Port';")
        status=$(sqlite3 -batch /xp/db/app.db "select status from firewall_configs where id = 1")
        if [ $status -eq 1 ]; then
            if ! command -v iptables &> /dev/null; then
                echo "iptables命令不可用，请安装iptables"
                exit 1
            fi
            iptables -D INPUT -p tcp --dport $oldPort -m state --state NEW -j ACCEPT
            iptables -I INPUT -p tcp --dport $port -m state --state NEW -j ACCEPT
        fi
        fp_id=$(sqlite3 -batch /xp/db/app.db "select id from firewall_ports where remark = '小皮面板端口' and protocol ='tcp'")
        if [ -z "$fp_id" ]; then
            addTime=$(date +"%Y-%m-%d %H:%M:%S")
            sqlite3 /xp/db/app.db "insert into firewall_ports (remark,port,created_time,updated_time) values ('小皮面板端口','$port','$addTime','$addTime')"
        else
            sqlite3 -batch /xp/db/app.db "update firewall_ports SET port='$port' where remark = '小皮面板端口' and protocol ='tcp';"
        fi
        sqlite3 -batch /xp/db/app.db "UPDATE panel_cfgs SET value='$port' WHERE section = 'panel' and key ='Port';"
        Panel_restart
        echo "| 新端口为：$port"
    else
        echo "端口格式不正确"
    fi
}
Panel_state(){
    sudo service xpd info
}
Panel_open(){
    sqlite3 -batch /xp/db/app.db "UPDATE  panel_cfgs SET value='true' WHERE section = 'base' and key ='PanelSwitch';"
    echo "面板已打开，现可通过web访问面板"
}
Panel_exit(){
    exit 1
}
Panel_fixdb(){
    echo "开始修复面板数据库"

    db_path="/xp/db"
    for file in ${db_path}/*.db; do
        if [[ -f $file ]]; then
            filename=$(basename $file)
            echo "修复 $filename 中..."
            sqlite3 -batch $file ".recover" > /dev/null
        fi
    done
    echo "修复结束"
}
Panel_uninstall(){
    echo -e "=================================================================="
    echo "====================================即将卸载小皮面板，是否继续（Y/n）"
    read ab
    if [[ $ab == "Y" ]]; then
        echo -e "=================================================================="
        echo "卸载小皮面板将会删除软件中心安装的所有软件和数据，请做好数据备份，是否确认卸载（Y/n）"
        read state
        if [[ $state == "Y" ]]; then
            pkill -f /xp/
            rm -rf /xp
            echo "已卸载小皮面板"
        else 
            exit 1
        fi
    else
    exit 1
    fi
}


# 检查输入是否为数字
if [[ $number =~ ^[0-9]+$ && $number -ge 0 && $number -le 11 ]]; then
echo  "=================================================================="
echo "正在执行编号($number)...."
echo "=================================================================="
    case $number in
        0)
        Panel_exit
        ;;
        1)
        Panel_restart
        ;;
        2)
        Panel_stop
        ;;
        3)
        Panel_start
        ;;
        4)
        Panel_editpwd
        ;;
        5)
        Panel_edituser
        ;;
        6)
        Panel_editport
        ;; 
        7)
        Panel_open
        ;;
        8)
        Panel_state
        ;; 
        9)
        Panel_safeport
        ;; 
        10)
        Panel_fixdb
        ;;  
         11)
        Panel_uninstall
        ;; 
        esac
else
    echo "错误：您输入的编号不正确·"
    exit 1
fi