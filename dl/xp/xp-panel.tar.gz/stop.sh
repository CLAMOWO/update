#!/bin/bash
pkill -f /xp/panel/app
pkill -f /xp/tasks/xp-task

echo "xp面板已停止"