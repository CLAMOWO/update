#!/bin/bash
ver=$1
if [ -z "$ver" ]; then
    echo "请输入版本号"
    exit 1
fi

echo "开始解压，版本为${ver}"

tmp_path="/xp/panel/tmp"

mkdir -p ${tmp_path}/xp-panel

tar -zxvf ${tmp_path}/xp-panel.tar.gz -C ${tmp_path}/xp-panel > /dev/null 2>&1

echo "正在替换资源文件"
cp -r ${tmp_path}/xp-panel/web/* /xp/web
cp -r ${tmp_path}/xp-panel/run.sh /xp
cp -r ${tmp_path}/xp-panel/stop.sh /xp
cp -r ${tmp_path}/xp-panel/xp.sh /xp

cp ${tmp_path}/xp-panel/init/xpd /etc/init.d/xpd
chmod +x /etc/init.d/xpd

cp ${tmp_path}/xp-panel/init/xpd.service /usr/lib/systemd/system/xpd.service
chmod +x /usr/lib/systemd/system/xpd.service
systemctl enable xpd

echo "正在停止服务"
bash /xp/stop.sh || echo "停止服务失败"

echo "正在替换程序"
cp -rf ${tmp_path}/xp-panel/panel/* /xp/panel || echo "覆盖xp-panel程序失败"
cp -rf ${tmp_path}/xp-panel/tasks/* /xp/tasks || echo "覆盖xp-tasks程序失败"

rm -rf ${tmp_path}/xp-panel
rm -rf ${tmp_path}/xp-panel.tar.gz

cd /xp

echo "正在更新版本号"
sqlite3 -batch /xp/db/app.db "update panel_cfgs set value = '$ver' where section = 'panel' and key = 'XPVersion';" || echo "更新版本号失败"

echo "正在启动服务"
sudo bash /xp/run.sh || echo "启动服务失败"

echo "更新结束"

cp -r ${tmp_path}/xp-panel/update.sh /xp